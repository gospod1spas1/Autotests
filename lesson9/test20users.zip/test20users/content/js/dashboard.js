/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.525, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6"], "isController": false}, {"data": [0.175, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345"], "isController": false}, {"data": [0.2, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0"], "isController": false}, {"data": [0.1, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/smart-tv"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348"], "isController": false}, {"data": [0.9, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/success"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6"], "isController": false}, {"data": [0.175, 500, 1500, "https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js"], "isController": false}, {"data": [0.2, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info"], "isController": false}, {"data": [0.3, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=product/product/getRecurringDescription"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/newyear.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js"], "isController": false}, {"data": [0.15625, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 920, 0, 0.0, 1465.331521739131, 40, 7216, 926.5, 5241.4, 5983.0999999999985, 6777.009999999999, 12.763596004439512, 130.3946678170089, 11.732027348085461], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6", 20, 0, 0.0, 69.6, 46, 134, 60.0, 116.80000000000003, 133.2, 134.0, 1.637599279456317, 10.637998444280685, 1.2489892941947107], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345", 20, 0, 0.0, 1559.4, 1196, 1812, 1545.0, 1796.5, 1811.25, 1812.0, 1.4530659691950014, 0.4909773684975298, 1.1834541194420227], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate", 20, 0, 0.0, 1565.4499999999998, 1400, 1909, 1541.5, 1830.4, 1905.5, 1909.0, 1.4394702749388226, 0.5004408377717, 1.4169785518929034], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js", 20, 0, 0.0, 55.150000000000006, 47, 91, 52.5, 62.900000000000006, 89.59999999999998, 91.0, 1.9615535504119261, 28.908012333267948, 1.4654184238917223], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android", 20, 0, 0.0, 5564.5, 4979, 6294, 5487.5, 6014.6, 6280.3, 6294.0, 1.0650761529449357, 36.78641977979551, 1.019311161998083], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout", 20, 0, 0.0, 6110.599999999999, 5341, 7192, 5926.0, 7037.8, 7184.75, 7192.0, 1.0860711376595167, 26.332452314689114, 1.0818286722780344], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0", 40, 0, 0.0, 3073.4750000000004, 2133, 3816, 3153.5, 3668.9, 3795.2999999999997, 3816.0, 1.8174383206869917, 6.138868261279477, 2.669362533509019], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki", 20, 0, 0.0, 4044.6000000000004, 1039, 7089, 3848.0, 6960.7, 7082.95, 7089.0, 1.7727353306151392, 60.53674755694912, 1.9285421467824855], "isController": false}, {"data": ["https://iwbm.ru/smart-tv", 20, 0, 0.0, 6395.4, 5692, 7216, 6266.0, 6821.5, 7196.5, 7216.0, 1.049042748492001, 29.431642161683712, 0.9916732231838447], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js", 20, 0, 0.0, 57.75, 46, 107, 51.0, 93.00000000000003, 106.35, 107.0, 1.9636720667648502, 17.62127209131075, 1.451659916543937], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki", 20, 0, 0.0, 5458.150000000001, 2694, 6747, 5825.0, 6427.4, 6731.2, 6747.0, 1.2462612163509472, 42.690410214668496, 1.1415947470089731], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add", 20, 0, 0.0, 1913.0, 1662, 2178, 1910.0, 2125.3, 2175.85, 2178.0, 1.3432735576600174, 0.907890262945799, 1.4023041339243738], "isController": false}, {"data": ["Test", 20, 0, 0.0, 67405.25, 64654, 68654, 67695.0, 68602.7, 68652.15, 68654.0, 0.27719643525384263, 130.2663532903217, 11.720482477720337], "isController": true}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js", 20, 0, 0.0, 54.6, 48, 64, 54.0, 60.800000000000004, 63.849999999999994, 64.0, 1.5883100381194408, 18.028249583068614, 1.3292790065120712], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js", 20, 0, 0.0, 85.54999999999998, 53, 160, 72.0, 140.70000000000002, 159.04999999999998, 160.0, 1.6256197675363733, 52.54847648947411, 1.2700154433877915], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348", 20, 0, 0.0, 1834.25, 1528, 2127, 1884.5, 2024.3000000000002, 2122.25, 2127.0, 1.549186676994578, 0.523455654531371, 1.275355828814872], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0", 20, 0, 0.0, 251.65000000000003, 102, 814, 126.0, 755.6000000000001, 811.55, 814.0, 1.954461057363432, 147.6954155672823, 1.5345573145705071], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/success", 20, 0, 0.0, 3126.1, 1547, 4237, 3513.5, 3958.5000000000005, 4223.8, 4237.0, 1.8545994065281899, 35.1359653189911, 1.715142224591988], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css", 20, 0, 0.0, 44.95, 40, 50, 44.5, 49.900000000000006, 50.0, 50.0, 1.9745285813012143, 2.011165342087077, 1.4866811876789416], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css", 20, 0, 0.0, 47.5, 43, 57, 47.5, 53.60000000000001, 56.849999999999994, 57.0, 1.9745285813012143, 6.640894955079475, 1.536815702438543], "isController": false}, {"data": ["https://iwbm.ru/newyear/style.css", 20, 0, 0.0, 46.85, 41, 61, 45.5, 56.30000000000001, 60.8, 61.0, 1.968503937007874, 2.3222194881889764, 1.4206293061023623], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6", 20, 0, 0.0, 117.0, 58, 246, 106.0, 178.30000000000004, 242.69999999999996, 246.0, 1.621796951021732, 19.651617742458644, 1.2496072210509244], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349", 20, 0, 0.0, 1746.85, 1229, 2996, 1567.5, 2896.2000000000003, 2991.2, 2996.0, 1.654533421575116, 0.6503415060390471, 1.4202489038716084], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android", 20, 0, 0.0, 5348.1, 4975, 6268, 5328.5, 5833.400000000001, 6246.549999999999, 6268.0, 1.064679265371307, 35.54510746606335, 1.0230902315677401], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css", 20, 0, 0.0, 51.74999999999999, 44, 84, 50.5, 59.40000000000001, 82.79999999999998, 84.0, 1.9749185346104474, 13.870716895428062, 1.510118371679668], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js", 20, 0, 0.0, 64.7, 54, 95, 61.0, 86.80000000000001, 94.6, 95.0, 1.9665683382497543, 59.84782141101278, 1.4710852999016717], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346", 20, 0, 0.0, 1549.9, 1310, 1865, 1551.5, 1726.2, 1858.1499999999999, 1865.0, 1.4814814814814814, 0.5309606481481481, 1.2991898148148149], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info", 20, 0, 0.0, 2068.9500000000003, 1776, 2601, 2048.0, 2379.1, 2590.0, 2601.0, 1.3271400132714002, 3.503507071167883, 1.3206598374253484], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347", 20, 0, 0.0, 1512.6999999999998, 1388, 1740, 1487.0, 1674.0000000000002, 1737.1, 1740.0, 1.4335889900365566, 0.5137960540463049, 1.257190344778152], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css", 20, 0, 0.0, 57.75, 47, 67, 57.5, 64.9, 66.9, 67.0, 1.9706375012316486, 41.5065523696916, 1.5029959848260914], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js", 20, 0, 0.0, 44.75, 42, 50, 44.0, 47.900000000000006, 49.9, 50.0, 1.9688915140775742, 2.8668137182516245, 1.4670549074620989], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=product/product/getRecurringDescription", 40, 0, 0.0, 1831.325, 1565, 2185, 1814.5, 1970.0, 2156.3499999999995, 2185.0, 2.4399170428205443, 0.8482524094180799, 2.5018680614859097], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css", 20, 0, 0.0, 46.349999999999994, 40, 60, 44.5, 55.60000000000001, 59.8, 60.0, 1.9747235387045812, 1.8763730499605056, 1.5369674417456556], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js", 20, 0, 0.0, 47.75000000000001, 44, 58, 46.0, 52.900000000000006, 57.75, 58.0, 1.9686977064671718, 8.953344940446893, 1.4534526036027167], "isController": false}, {"data": ["https://iwbm.ru/newyear/newyear.js", 20, 0, 0.0, 45.74999999999999, 40, 68, 44.0, 48.900000000000006, 67.04999999999998, 68.0, 1.9688915140775742, 2.4284277170702895, 1.3959133195510929], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css", 20, 0, 0.0, 46.4, 40, 61, 45.5, 52.7, 60.599999999999994, 61.0, 1.9770660340055357, 1.1410605723606169, 1.5001760824436536], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js", 20, 0, 0.0, 50.2, 44, 80, 49.0, 56.0, 78.79999999999998, 80.0, 1.9615535504119261, 14.845742202824637, 1.4596716849745], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned", 80, 0, 0.0, 1579.9999999999995, 1328, 1917, 1555.0, 1774.2000000000003, 1866.75, 1917.0, 3.3912674862229757, 0.9107407799915218, 4.7979480182280625], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css", 20, 0, 0.0, 45.69999999999999, 40, 57, 44.0, 54.900000000000006, 56.9, 57.0, 1.9770660340055357, 0.7529841340450771, 1.4789380684064848], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6", 20, 0, 0.0, 50.199999999999996, 40, 93, 47.0, 61.40000000000001, 91.44999999999997, 93.0, 1.637331150225133, 1.9411328284895621, 1.2967534793286943], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css", 20, 0, 0.0, 49.0, 42, 76, 47.5, 60.90000000000002, 75.29999999999998, 76.0, 1.9751135690302193, 7.017053871222596, 1.494836929685957], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css", 20, 0, 0.0, 46.8, 40, 57, 45.5, 52.900000000000006, 56.8, 57.0, 1.590583744234134, 2.0565750755527277, 1.3544814696993797], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 920, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
