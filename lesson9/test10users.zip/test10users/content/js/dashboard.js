/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6627659574468086, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout"], "isController": false}, {"data": [0.175, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0"], "isController": false}, {"data": [0.25, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/smart-tv"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js"], "isController": false}, {"data": [0.1, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js"], "isController": false}, {"data": [0.55, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0"], "isController": false}, {"data": [0.4, 500, 1500, "https://iwbm.ru/index.php?route=checkout/success"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=product/product/getRecurringDescription"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/newyear.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js"], "isController": false}, {"data": [0.5, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 460, 0, 0.0, 664.9434782608698, 39, 3216, 265.0, 2082.400000000001, 2613.85, 3003.7799999999997, 13.53737492642731, 138.16465453023838, 12.443268558711008], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6", 10, 0, 0.0, 52.900000000000006, 45, 62, 51.0, 61.9, 62.0, 62.0, 1.2761613067891782, 8.290063489025012, 0.9733222466819805], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345", 10, 0, 0.0, 791.3000000000001, 572, 971, 790.0, 969.1, 971.0, 971.0, 1.180776951233912, 0.39897346203802103, 0.9616874778604322], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate", 10, 0, 0.0, 767.6999999999999, 530, 1024, 754.5, 1015.8000000000001, 1024.0, 1024.0, 1.1708230886313078, 0.4070439644069781, 1.1525289778714436], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js", 10, 0, 0.0, 54.300000000000004, 49, 62, 53.0, 61.9, 62.0, 62.0, 1.6420361247947455, 24.19918667898194, 1.2267164408866995], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android", 10, 0, 0.0, 2326.7000000000003, 2020, 2794, 2257.5, 2776.0, 2794.0, 2794.0, 1.0399334442595674, 35.958643959286604, 0.9952488040765392], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout", 10, 0, 0.0, 2722.5, 2085, 3216, 2815.5, 3196.9, 3216.0, 3216.0, 0.9548362455838824, 22.93154868471307, 0.9511064164995703], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0", 20, 0, 0.0, 1464.15, 807, 1949, 1597.0, 1928.6000000000004, 1948.55, 1949.0, 1.5997440409534474, 5.054816229403295, 2.3496240601503757], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki", 10, 0, 0.0, 1702.6999999999998, 622, 3000, 1569.0, 2977.7000000000003, 3000.0, 3000.0, 1.398014818957081, 47.773197216202995, 1.5208872151544808], "isController": false}, {"data": ["https://iwbm.ru/smart-tv", 10, 0, 0.0, 2772.0, 2611, 3048, 2701.5, 3043.5, 3048.0, 3048.0, 0.9798157946306093, 27.59444505682932, 0.926232118361748], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js", 10, 0, 0.0, 51.6, 47, 57, 52.0, 56.8, 57.0, 57.0, 1.6420361247947455, 14.735029248768473, 1.2138880336617406], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki", 10, 0, 0.0, 1986.6000000000001, 912, 3005, 2071.5, 2946.8, 3005.0, 3005.0, 1.1936022917164002, 40.88717287837193, 1.0933583492480305], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add", 10, 0, 0.0, 801.1, 635, 952, 829.0, 950.8, 952.0, 952.0, 1.215066828675577, 0.8205260859659781, 1.2684633201701092], "isController": false}, {"data": ["Test", 10, 0, 0.0, 30587.4, 29567, 31208, 30611.5, 31196.6, 31208.0, 31208.0, 0.2936943816264795, 137.8846650690916, 12.418052384064143], "isController": true}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js", 10, 0, 0.0, 55.49999999999999, 45, 70, 54.5, 69.2, 70.0, 70.0, 1.3296104241457252, 15.09185738266188, 1.1127696616141471], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js", 10, 0, 0.0, 81.8, 61, 111, 74.5, 110.2, 111.0, 111.0, 1.2727504136438843, 41.14190570510373, 0.9943362606592847], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348", 10, 0, 0.0, 735.3000000000001, 468, 1109, 679.5, 1092.0, 1109.0, 1109.0, 1.449905756125852, 0.48990956212846165, 1.1936235863418878], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0", 10, 0, 0.0, 116.2, 96, 193, 106.0, 186.40000000000003, 193.0, 193.0, 1.6374652038644177, 123.74055898968396, 1.2856660389716719], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/success", 10, 0, 0.0, 1159.1000000000001, 567, 1850, 1224.5, 1824.1000000000001, 1850.0, 1850.0, 1.9623233908948192, 37.17682986656201, 1.814765870290424], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css", 10, 0, 0.0, 47.599999999999994, 42, 58, 46.5, 57.400000000000006, 58.0, 58.0, 1.643925694558606, 1.6744282220943614, 1.2377604594772316], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css", 10, 0, 0.0, 47.5, 40, 55, 47.0, 54.7, 55.0, 55.0, 1.6428454082470838, 5.525351158206013, 1.2786599515360606], "isController": false}, {"data": ["https://iwbm.ru/newyear/style.css", 10, 0, 0.0, 46.3, 40, 51, 47.0, 51.0, 51.0, 51.0, 1.6433853738701725, 1.9386811832374693, 1.1859978430566969], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6", 10, 0, 0.0, 70.30000000000001, 58, 82, 70.5, 82.0, 82.0, 82.0, 1.2759984688018373, 15.461512696184766, 0.9831667889498533], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349", 10, 0, 0.0, 1006.6999999999999, 337, 2103, 661.5, 2069.3, 2103.0, 2103.0, 1.6326530612244898, 0.6991390306122449, 1.4014668367346939], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android", 10, 0, 0.0, 2224.1, 2024, 2710, 2136.5, 2685.3, 2710.0, 2710.0, 1.049648367796788, 35.04574990815577, 1.0086464784297262], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css", 10, 0, 0.0, 50.9, 42, 63, 49.5, 62.400000000000006, 63.0, 63.0, 1.6377333770062235, 11.502518015067148, 1.2522902677694072], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js", 10, 0, 0.0, 59.60000000000001, 55, 68, 58.0, 67.6, 68.0, 68.0, 1.6412276382734285, 49.94685243311997, 1.2277152059740686], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346", 10, 0, 0.0, 791.2, 659, 897, 803.5, 893.6, 897.0, 897.0, 1.1208249271463797, 0.4017019026003138, 0.982910922438915], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info", 10, 0, 0.0, 861.6999999999999, 678, 1098, 851.0, 1082.7, 1098.0, 1098.0, 1.2156576707999027, 3.2085527215536103, 1.2097218423292], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347", 10, 0, 0.0, 733.2, 523, 954, 758.0, 947.2, 954.0, 954.0, 1.2103606874848705, 0.43379137920600336, 1.0614295872670054], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css", 10, 0, 0.0, 58.599999999999994, 52, 66, 57.5, 65.9, 66.0, 66.0, 1.6278691193228065, 34.28699332573661, 1.2415681466710078], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js", 10, 0, 0.0, 47.5, 41, 57, 46.0, 56.8, 57.0, 57.0, 1.6463615409944024, 2.397192439084623, 1.2267322810339152], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=product/product/getRecurringDescription", 20, 0, 0.0, 811.45, 645, 1159, 796.5, 977.0000000000002, 1150.4499999999998, 1159.0, 2.1920210434020166, 0.7620698158702323, 2.247677827707146], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css", 10, 0, 0.0, 47.1, 43, 52, 46.0, 52.0, 52.0, 52.0, 1.6425755584756898, 1.5607675960906702, 1.278449921977661], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js", 10, 0, 0.0, 49.2, 41, 59, 48.5, 58.7, 59.0, 59.0, 1.6463615409944024, 7.487407906651301, 1.2154778564372737], "isController": false}, {"data": ["https://iwbm.ru/newyear/newyear.js", 10, 0, 0.0, 46.1, 39, 51, 46.5, 50.9, 51.0, 51.0, 1.64446637066272, 2.0282822520966945, 1.1659009620128267], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css", 10, 0, 0.0, 47.4, 43, 52, 47.5, 51.9, 52.0, 52.0, 1.6414970453053186, 0.9473874548588314, 1.2455500041037426], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js", 10, 0, 0.0, 49.3, 43, 57, 49.0, 56.6, 57.0, 57.0, 1.6428454082470838, 12.433644447182521, 1.2225080088713653], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned", 40, 0, 0.0, 846.5999999999999, 621, 1122, 861.0, 993.9, 1095.85, 1122.0, 2.9572674848440044, 0.7941880452461926, 4.183927020183351], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css", 10, 0, 0.0, 45.8, 39, 51, 46.5, 50.9, 51.0, 51.0, 1.6406890894175554, 0.6248718211648893, 1.2273123461853979], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6", 10, 0, 0.0, 47.0, 43, 53, 46.5, 52.7, 53.0, 53.0, 1.2813941568426448, 1.5191528382880573, 1.0148541613275244], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css", 10, 0, 0.0, 48.0, 41, 56, 46.5, 56.0, 56.0, 56.0, 1.6363933889707085, 5.8136710440189825, 1.2384813246604485], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css", 10, 0, 0.0, 47.4, 42, 59, 45.0, 58.5, 59.0, 59.0, 1.327844907714779, 1.716861970521843, 1.1307429292258664], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 460, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
