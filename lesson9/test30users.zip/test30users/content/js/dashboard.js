/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4858156028368794, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/smart-tv"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348"], "isController": false}, {"data": [0.8166666666666667, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0"], "isController": false}, {"data": [0.016666666666666666, 500, 1500, "https://iwbm.ru/index.php?route=checkout/success"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6"], "isController": false}, {"data": [0.016666666666666666, 500, 1500, "https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=product/product/getRecurringDescription"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/newyear/newyear.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1380, 0, 0.0, 2442.1463768115946, 35, 14390, 986.5, 7403.000000000003, 9133.650000000001, 11695.450000000003, 11.700567223150165, 119.78078128841898, 10.754913787804279], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6", 30, 0, 0.0, 112.26666666666668, 47, 315, 87.5, 191.60000000000002, 266.5999999999999, 315.0, 1.2993762993762994, 8.440870257276506, 0.9910282127079002], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345", 30, 0, 0.0, 2648.6333333333337, 2073, 3042, 2688.5, 2929.3, 2991.95, 3042.0, 1.164551065564225, 0.393490887387912, 0.9484722545708629], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate", 30, 0, 0.0, 2891.966666666666, 2607, 3320, 2880.5, 3134.3, 3310.65, 3320.0, 1.1046468812136387, 0.39306299018705354, 1.0873867736946756], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js", 30, 0, 0.0, 133.16666666666669, 45, 334, 142.0, 237.60000000000002, 310.34999999999997, 334.0, 2.336448598130841, 34.43295487733645, 1.7454913843457944], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android", 30, 0, 0.0, 9481.76666666667, 6558, 12545, 9433.0, 11092.4, 11920.199999999999, 12545.0, 1.0283128813326934, 35.594086344004936, 0.9841275622129293], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout", 30, 0, 0.0, 10707.133333333335, 9050, 12204, 10565.5, 12090.2, 12201.8, 12204.0, 0.8534122265524992, 20.655326136816203, 0.8500785850425284], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0", 60, 0, 0.0, 5932.133333333333, 3374, 7114, 6322.5, 6937.7, 7081.3, 7114.0, 1.4385729356478374, 5.428177747674307, 2.112903999232761], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki", 30, 0, 0.0, 6984.666666666669, 2149, 9952, 8396.0, 9358.9, 9845.85, 9952.0, 2.1422450728363325, 73.1824249991074, 2.3305283311910885], "isController": false}, {"data": ["https://iwbm.ru/smart-tv", 30, 0, 0.0, 9793.599999999999, 7548, 14390, 8947.5, 12643.900000000001, 13595.249999999998, 14390.0, 1.1285407967498025, 31.63712769909341, 1.0668237219275478], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js", 30, 0, 0.0, 125.83333333333331, 49, 303, 128.0, 210.20000000000002, 279.9, 303.0, 2.318750966146236, 20.80761975382594, 1.714154766965528], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki", 30, 0, 0.0, 7723.500000000001, 5334, 9236, 8033.0, 8847.1, 9200.8, 9236.0, 1.386001386001386, 47.476863883113886, 1.269598925848926], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add", 30, 0, 0.0, 3097.0, 1827, 5086, 2989.0, 3928.8000000000006, 4677.349999999999, 5086.0, 1.1563367252543941, 0.7824093480188098, 1.207152304000925], "isController": false}, {"data": ["Test", 30, 0, 0.0, 112338.73333333334, 107445, 114705, 112801.0, 114342.7, 114593.9, 114705.0, 0.25417482144218795, 119.69350488015658, 10.747077386701573], "isController": true}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js", 30, 0, 0.0, 57.46666666666666, 46, 81, 55.0, 68.80000000000001, 80.45, 81.0, 2.1933031144904227, 24.89527548800994, 1.8356062198420822], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js", 30, 0, 0.0, 171.13333333333335, 66, 342, 147.5, 314.70000000000005, 341.45, 342.0, 1.2974656171611452, 41.94082948598737, 1.0136450134071446], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348", 30, 0, 0.0, 3242.9999999999995, 2155, 3802, 3355.0, 3627.0, 3776.7, 3802.0, 1.3065064018813692, 0.44145626469819704, 1.0755711882675725], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0", 30, 0, 0.0, 384.0333333333333, 124, 857, 354.5, 727.7, 851.5, 857.0, 2.297266253158741, 173.60064179875948, 1.8037129565816679], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/success", 30, 0, 0.0, 4952.900000000001, 1116, 7624, 5075.5, 7225.7, 7513.45, 7624.0, 1.7182130584192439, 32.55040539089347, 1.589011490549828], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css", 30, 0, 0.0, 115.5, 42, 333, 75.0, 259.7, 293.4, 333.0, 2.409058058299205, 2.4537573777403034, 1.8138513310045774], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css", 30, 0, 0.0, 107.30000000000001, 43, 351, 71.0, 222.60000000000002, 314.69999999999993, 351.0, 2.419549963706751, 8.137627026373096, 1.8831848838616019], "isController": false}, {"data": ["https://iwbm.ru/newyear/style.css", 30, 0, 0.0, 103.73333333333333, 38, 358, 79.0, 196.10000000000005, 280.44999999999993, 358.0, 2.3203650707711345, 2.737305669425323, 1.6745603391600279], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6", 30, 0, 0.0, 180.20000000000002, 64, 293, 163.5, 261.9, 289.15, 293.0, 1.2939958592132506, 15.679590450310558, 0.9970339188664595], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349", 30, 0, 0.0, 2844.4333333333334, 1279, 4553, 2723.5, 4182.9000000000015, 4474.349999999999, 4553.0, 1.4356814701378255, 0.5792264368778713, 1.2323867307140122], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android", 30, 0, 0.0, 7387.633333333334, 6491, 8410, 7295.0, 8336.4, 8403.95, 8410.0, 1.3731233980227022, 45.84274375800989, 1.3194857652874405], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css", 30, 0, 0.0, 139.36666666666667, 47, 318, 127.0, 261.6, 298.2, 318.0, 2.450379808870375, 17.210089438863022, 1.8736790921342807], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js", 30, 0, 0.0, 146.13333333333335, 53, 344, 120.0, 291.40000000000003, 323.09999999999997, 344.0, 2.375108859156045, 72.28077868933576, 1.7766927598764943], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346", 30, 0, 0.0, 2777.066666666667, 2101, 3194, 2815.0, 3102.5, 3156.6, 3194.0, 1.1697274535033337, 0.4293950681366242, 1.0257961457480407], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info", 30, 0, 0.0, 3512.1666666666665, 2693, 5339, 3370.0, 4230.3, 4884.15, 5339.0, 1.1221665295129797, 3.0445342307548438, 1.1166872007555921], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347", 30, 0, 0.0, 2886.2, 2407, 3328, 2886.0, 3105.6, 3232.2999999999997, 3328.0, 1.1221665295129797, 0.42201790089399266, 0.9840874448268122], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css", 30, 0, 0.0, 174.93333333333334, 54, 460, 119.5, 367.70000000000005, 415.99999999999994, 460.0, 2.4923153609703412, 52.494392290437816, 1.9008772430838248], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js", 30, 0, 0.0, 83.60000000000002, 35, 223, 53.5, 154.8, 214.2, 223.0, 2.313386798272671, 3.36841769162554, 1.7237442647285626], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=product/product/getRecurringDescription", 60, 0, 0.0, 2442.8333333333344, 1750, 3111, 2370.0, 2817.0, 2914.2499999999995, 3111.0, 3.2357223750202233, 1.1644176710888205, 3.317879388448471], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css", 30, 0, 0.0, 114.93333333333334, 41, 351, 66.5, 242.90000000000003, 350.45, 351.0, 2.4344721252941652, 2.3132240018664287, 1.8947991053314939], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js", 30, 0, 0.0, 86.83333333333333, 37, 313, 50.0, 213.6000000000001, 264.5999999999999, 313.0, 2.3139220979560355, 10.523374228692633, 1.7083252988816044], "isController": false}, {"data": ["https://iwbm.ru/newyear/newyear.js", 30, 0, 0.0, 91.76666666666664, 37, 254, 66.0, 178.40000000000006, 215.49999999999994, 254.0, 2.3157082207641837, 2.8561909011964492, 1.6418009455808569], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css", 30, 0, 0.0, 108.3, 41, 233, 71.0, 228.4, 232.45, 233.0, 2.4392227010326044, 1.4077935706154971, 1.8508555065452477], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js", 30, 0, 0.0, 130.59999999999997, 40, 258, 120.5, 239.70000000000002, 252.5, 258.0, 2.3610892491736184, 17.869571954194868, 1.7569824295608374], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned", 120, 0, 0.0, 2903.4749999999995, 2139, 3738, 2881.5, 3210.9, 3495.8499999999995, 3701.6699999999987, 2.688352711875798, 0.7293425647444944, 3.803467764970764], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css", 30, 0, 0.0, 123.3, 39, 329, 77.5, 235.0, 289.4, 329.0, 2.4443901246638964, 0.9309688951356637, 1.8285183940356882], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6", 30, 0, 0.0, 181.89999999999998, 43, 667, 161.0, 340.8, 503.0999999999998, 667.0, 1.3002773925104023, 1.5415397993238558, 1.0298095364511095], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css", 30, 0, 0.0, 121.73333333333332, 41, 266, 97.0, 243.4, 259.4, 266.0, 2.471169686985173, 8.779409493410213, 1.8702700267710048], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css", 30, 0, 0.0, 49.199999999999996, 40, 67, 47.5, 63.0, 65.9, 67.0, 2.1949078138718177, 2.8379472124670766, 1.8691011852502195], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1380, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
