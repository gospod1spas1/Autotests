/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 50.28260869565217, "KoPercent": 49.71739130434783};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4634042553191489, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate"], "isController": false}, {"data": [0.97, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/smart-tv"], "isController": false}, {"data": [0.955, 500, 1500, "https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.975, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348"], "isController": false}, {"data": [0.585, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/success"], "isController": false}, {"data": [0.975, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css"], "isController": false}, {"data": [0.995, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css"], "isController": false}, {"data": [0.955, 500, 1500, "https://iwbm.ru/newyear/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android"], "isController": false}, {"data": [0.93, 500, 1500, "https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css"], "isController": false}, {"data": [0.96, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347"], "isController": false}, {"data": [0.885, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css"], "isController": false}, {"data": [0.93, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=product/product/getRecurringDescription"], "isController": false}, {"data": [0.985, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css"], "isController": false}, {"data": [0.94, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js"], "isController": false}, {"data": [0.945, 500, 1500, "https://iwbm.ru/newyear/newyear.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css"], "isController": false}, {"data": [0.975, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned"], "isController": false}, {"data": [0.995, 500, 1500, "https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6"], "isController": false}, {"data": [0.885, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css"], "isController": false}, {"data": [0.94, 500, 1500, "https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4600, 2287, 49.71739130434783, 720.0369565217384, 34, 16612, 131.0, 549.9000000000005, 2591.3499999999867, 13981.98, 128.89847843752628, 754.2294813237314, 129.51144674531344], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://iwbm.ru/catalog/view/javascript/simple.js?v=4.11.6", 100, 0, 0.0, 217.1, 42, 388, 244.0, 340.8, 347.95, 387.98, 49.82561036372696, 323.6718360737419, 41.40780705032386], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345", 100, 100, 100.0, 291.84999999999997, 41, 613, 235.5, 555.9, 570.0, 612.7299999999999, 50.0751126690035, 35.942585753630446, 44.20693540310465], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate", 100, 100, 100.0, 42.530000000000015, 34, 134, 37.0, 46.0, 53.74999999999994, 134.0, 190.11406844106463, 136.45882842205322, 200.1396150190114], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/bootstrap.min.js", 100, 0, 0.0, 283.33, 83, 1833, 249.0, 404.8000000000001, 527.7499999999995, 1821.7199999999943, 7.672830507174097, 113.07684099976981, 6.601331715644902], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android", 100, 100, 100.0, 516.7700000000003, 35, 9868, 69.0, 119.30000000000004, 7573.749999999912, 9865.169999999998, 9.358038555118847, 6.716951501965188, 9.627630486150103], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout", 100, 100, 100.0, 155.64000000000001, 36, 604, 136.0, 348.0, 357.69999999999993, 601.6499999999987, 59.488399762046406, 42.69919318857823, 63.32261302795955], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0", 200, 200, 100.0, 48.83500000000001, 34, 409, 38.0, 45.900000000000006, 68.0, 408.8800000000001, 174.82517482517483, 125.4848666958042, 268.72541520979024], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki", 100, 87, 87.0, 12970.139999999998, 4441, 16612, 13785.0, 15862.6, 16301.849999999999, 16610.79, 5.662514156285391, 28.406300874150624, 6.160196064552661], "isController": false}, {"data": ["https://iwbm.ru/smart-tv", 100, 100, 100.0, 686.6300000000002, 34, 10400, 62.0, 2116.600000000012, 7581.449999999954, 10399.189999999999, 7.752538956508256, 5.541096935808977, 7.885028635940771], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/ui/ion.rangeslider.min.js", 100, 0, 0.0, 315.79999999999995, 79, 1927, 271.0, 380.9, 743.4499999999982, 1926.85, 7.620208793720948, 68.38095566943535, 6.496525661053113], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki", 100, 100, 100.0, 8497.470000000001, 575, 11933, 11293.5, 11682.7, 11817.9, 11932.15, 6.474168069403082, 4.5184508732034185, 6.663840962061375], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add", 100, 100, 100.0, 95.8, 35, 1046, 87.0, 120.0, 132.5499999999999, 1037.3599999999956, 49.87531172069826, 35.79917394014963, 55.476543017456365], "isController": false}, {"data": ["Test", 100, 100, 100.0, 33121.7, 30641, 35330, 33130.5, 35088.6, 35236.55, 35329.77, 2.7939204291461777, 752.0168613097899, 129.1315098345999], "isController": true}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.js", 100, 0, 0.0, 160.89999999999995, 49, 1039, 91.5, 306.8, 905.5499999999938, 1038.97, 6.99154023631406, 79.35807828777179, 6.35315252918968], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/jquery/jquery.inputmask.bundle.min.js", 100, 0, 0.0, 234.72, 87, 436, 248.5, 363.8, 391.5499999999999, 435.8299999999999, 50.050050050050054, 1617.8776432682682, 42.52299174174174], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348", 100, 100, 100.0, 39.51999999999998, 34, 70, 39.0, 45.0, 46.0, 69.94999999999997, 219.29824561403507, 157.40645559210526, 195.52665844298244], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0", 100, 0, 0.0, 855.7599999999998, 328, 5714, 656.5, 893.1000000000006, 3857.499999999978, 5713.88, 9.894132779261898, 747.6833815672306, 8.889259918868111], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/success", 100, 100, 100.0, 41.28000000000001, 34, 65, 42.0, 46.900000000000006, 56.89999999999998, 65.0, 210.08403361344537, 150.79273897058823, 208.64791228991598], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/custom.css", 100, 0, 0.0, 170.28999999999994, 70, 1842, 107.0, 283.00000000000006, 490.64999999999947, 1830.6599999999942, 7.668123610152596, 7.810403247450349, 6.642212541216164], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/user_style/user_style.css", 100, 0, 0.0, 162.6299999999999, 65, 533, 136.0, 286.80000000000007, 310.69999999999993, 532.6299999999998, 7.750135627373479, 26.065885840502208, 6.910033034953112], "isController": false}, {"data": ["https://iwbm.ru/newyear/style.css", 100, 0, 0.0, 260.5799999999999, 103, 3053, 185.0, 370.20000000000005, 677.949999999998, 3040.3899999999935, 8.000640051204096, 9.438255060404831, 6.68022191775342], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/simplecheckout.js?v=4.11.6", 100, 0, 0.0, 246.03000000000003, 50, 398, 296.5, 381.9, 388.84999999999997, 397.98, 49.5785820525533, 600.7529747149232, 41.58984568666337], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349", 100, 100, 100.0, 41.290000000000006, 34, 74, 40.0, 47.900000000000006, 57.74999999999994, 74.0, 214.13276231263384, 153.69880888650962, 198.44921038543896], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android", 100, 100, 100.0, 1850.21, 57, 10410, 150.5, 8447.0, 9576.849999999995, 10409.41, 6.807351940095303, 4.861273613002043, 7.219515827093261], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/font-awesome/css/font-awesome.min.css", 100, 0, 0.0, 351.34999999999997, 80, 1726, 291.5, 414.9000000000001, 1572.0, 1725.79, 7.521058965102286, 52.82368757521059, 6.602960946901324], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/jquery-3.5.1.min.js", 100, 0, 0.0, 309.53, 120, 1925, 281.5, 432.8, 569.0999999999996, 1913.389999999994, 7.519927808693036, 228.8510842795909, 6.477125319596932], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346", 100, 100, 100.0, 96.16, 34, 605, 39.0, 334.2000000000003, 530.0, 604.2799999999996, 56.11672278338945, 40.279093013468014, 53.04783950617284], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info", 100, 100, 100.0, 105.61000000000003, 35, 348, 93.0, 149.8, 159.84999999999997, 346.8099999999994, 76.56967840735068, 54.959681278713624, 81.43005838437978], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347", 100, 100, 100.0, 38.37999999999999, 34, 46, 38.0, 43.0, 44.0, 45.989999999999995, 228.8329519450801, 164.25021453089244, 216.3186498855835], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/css/bootstrap.min.css", 100, 0, 0.0, 530.39, 65, 2136, 415.0, 1180.6000000000008, 1576.9999999999982, 2131.4799999999977, 7.61208799573723, 160.3296034102154, 6.668010675953414], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/ft.livesearch.js", 100, 0, 0.0, 321.49000000000007, 91, 3022, 197.0, 379.70000000000005, 1898.0, 3018.239999999998, 8.582954252853831, 12.497250772465883, 7.36759451978371], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=product/product/getRecurringDescription", 200, 200, 100.0, 250.96500000000015, 36, 11675, 79.0, 658.1000000000003, 704.75, 3962.0600000000145, 14.148273910582908, 10.06530865343803, 15.52303294779287], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/filter_vier/other/ion.rangeslider.css", 100, 0, 0.0, 188.99999999999991, 79, 1889, 173.5, 246.70000000000013, 284.1999999999998, 1875.409999999993, 7.696451935657661, 7.313132552143462, 6.862168571538521], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/common.js", 100, 0, 0.0, 252.17000000000013, 92, 1979, 123.0, 353.9000000000003, 1500.3999999999992, 1978.8, 8.816787162757892, 40.09743927437842, 7.508045318286016], "isController": false}, {"data": ["https://iwbm.ru/newyear/newyear.js", 100, 0, 0.0, 272.02000000000015, 99, 1965, 197.0, 386.1, 802.149999999999, 1961.4199999999983, 8.261049153242462, 10.18916511771995, 6.792776745146633], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/default/stylesheet/hand_links_fv.css", 100, 0, 0.0, 175.75000000000003, 57, 450, 144.5, 376.8000000000002, 396.4499999999999, 449.6499999999998, 7.572315614114796, 4.370350124943208, 6.60359164394972], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/bootstrap/js/popper.min.js", 100, 0, 0.0, 260.8299999999997, 82, 1296, 224.5, 380.9, 542.6999999999995, 1291.6799999999978, 7.574609907589759, 57.327369906074836, 6.494636229359188], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned", 400, 400, 100.0, 112.50999999999995, 34, 622, 41.0, 284.100000000001, 471.84999999999997, 605.98, 187.61726078799248, 134.66668621013133, 278.2653465056285], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/javascript/mylabelpro/style.css", 100, 0, 0.0, 181.93999999999994, 52, 514, 157.0, 330.9000000000001, 373.7499999999997, 513.6799999999998, 7.509762691498949, 2.860163525082607, 6.468369818263742], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/simple.css?v=4.11.6", 100, 0, 0.0, 189.70000000000002, 40, 397, 108.5, 376.70000000000005, 390.0, 396.95, 51.57297576070139, 61.14218024755028, 44.370890278494066], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/stylesheet/stylesheet.css", 100, 0, 0.0, 438.89999999999986, 88, 2722, 272.5, 1050.2000000000005, 1997.6499999999996, 2720.7299999999996, 7.498500299940012, 26.64017977654469, 6.524573991451709], "isController": false}, {"data": ["https://iwbm.ru/catalog/view/theme/ft_frame/javascript/owl-carousel/owl.carousel.min.css", 100, 0, 0.0, 222.5699999999999, 65, 1964, 110.5, 199.10000000000005, 1369.299999999996, 1963.99, 6.9949636261891435, 9.044269376049245, 6.458728621642417], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 2121, 92.74158285964145, 46.108695652173914], "isController": false}, {"data": ["500/Internal Server Error", 166, 7.2584171403585485, 3.608695652173913], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4600, 2287, "502/Bad Gateway", 2121, "500/Internal Server Error", 166, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/human&_=1702827555345", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout_shipping/validate", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-m98-game-tv-stick-8k-16-2gb-android", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout&group=0", 200, 200, "502/Bad Gateway", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/igrovye-pristavki", 100, 87, "500/Internal Server Error", 81, "502/Bad Gateway", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/smart-tv", 100, 100, "502/Bad Gateway", 95, "500/Internal Server Error", 5, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki", 100, 100, "502/Bad Gateway", 56, "500/Internal Server Error", 44, "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/add", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/prevent_delete&_=1702827555348", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/success", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/payment/cod/confirm&_=1702827555349", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/televizory-proektory-pristavki-i-aksessuary/tv-pristavki/tv-pristavka-x98-s500-16-2gb-android", 100, 100, "502/Bad Gateway", 85, "500/Internal Server Error", 15, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555346", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=extension/module/frametheme/ft_cart/info", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=common/simple_connector/validate&method=checkEmailForUniqueness&filter=0&value=mail%40mail.ru&_=1702827555347", 100, 100, "502/Bad Gateway", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=product/product/getRecurringDescription", 200, 200, "502/Bad Gateway", 179, "500/Internal Server Error", 21, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://iwbm.ru/index.php?route=checkout/simplecheckout/abandoned", 400, 400, "502/Bad Gateway", 400, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
